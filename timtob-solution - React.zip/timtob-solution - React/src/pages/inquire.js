import React from 'react'
import Quote from '../components/Quote'

const Inquire = () => {
    return (
        <div>
            <Quote />
        </div>
    )
}

export default Inquire;
